import { errors, test, expect, type Page } from '@playwright/test'; 
import { getAdeptEnvironment } from '../config/adept';
// 📦 Playwright's core test framework (gives us `test`, `expect`, and running capabilities)

import * as fs from 'fs';
// 🗂️ Node.js built-in File System module. We use this to write JSON files.

// ============================================================
// CONFIGURABLE CONSTANTS
// ============================================================
const MAX_WAIT_SECONDS = 60; // ⏱️ Maximum time to wait for ALL curves to generate
const FLOW_VALUE = "900";    // 💧 Total System Flow
const HEAD_VALUE = "100";    // 📏 System Head

// ============================================================
// INTERFACES: These are like "blueprints" for the data we will work with.
// ============================================================

interface CurveData {
    // 📊 Represents the data returned from the "Get Curve" API
    title: string;          // The main title (e.g., "Series 4322")
    subTitle: string;       // The sub-title (e.g., "3x3x5 @ 3762 rpm")
    curveSeries: any[];     // The array of X/Y coordinates that make up the curve
}

interface RowResult {
    // 📋 Represents the result of waiting for a curve in a specific row
    row: number;            // Row number (1-based)
    status: string;         // "✅ PASSED" or "❌ FAILED"
    time: number;           // Time taken in seconds
}

// ADEPT can close or rebuild the category menu while the selection page is loading.
async function selectCommercialPumps(page: Page): Promise<void> {
    const category = page.getByLabel('Select box activate');
    const commercialPumps = page.getByRole('link', { name: 'Commercial Pumps', exact: true });

    for (let attempt = 1; attempt <= 4; attempt++) {
        try {
            if (await category.isVisible()) {
                await category.click({ timeout: 5_000 });
            }
            await commercialPumps.click({ timeout: 5_000 });
            return;
        } catch (error) {
            if (!(error instanceof errors.TimeoutError) || attempt === 4) throw error;
            console.log(`Category selection not ready; retrying (${attempt}/4).`);
        }
    }
}

// ============================================================
// TEST: The main executable block
// ============================================================

test('Validate Multiple Pump Curve Data & Image Generation', async ({ page }, testInfo) => {
    test.setTimeout(120_000);
    // `test` = Playwright's test function
    // `async` = Allows us to use `await` (wait for things to finish) inside this function
    // `({ page })` = Playwright automatically gives us a `page` object that controls the browser
    // `testInfo` = Playwright's test information object (for attaching files)

    // Array to capture all console.log outputs
    const consoleOutput: string[] = [];
    
    // Helper function to capture logs
    const log = (message: string) => {
        console.log(message);
        consoleOutput.push(message);
    };

    // ------------------------------------------------------------
    // STEP 1: Navigate to the app
    // ------------------------------------------------------------
    log("\n[STEP] Navigating to application URL...");
    const { environment, baseUrl } = getAdeptEnvironment();
    log(`ADEPT environment: ${environment}`);
    await page.goto(baseUrl);
    // `page.goto()` tells the browser to go to this URL. The `await` waits until the page starts loading.

    // Dismiss month-specific Release Notes whenever they interrupt a later action.
    const releaseTitle = page.getByText(
        /^\s*(?:January|February|March|April|May|June|July|August|September|October|November|December)(?:\s+\d{4})?\s+Release(?:\s+Notes)?\s*$/i,
    ).filter({ visible: true });
    // Scope Dismiss to the closest container shared with the release title.
    const releasePage = releaseTitle.first().locator('xpath=ancestor::*[.//*[normalize-space(.)="Dismiss"]][1]');
    const releaseDismiss = releasePage.getByRole('button', { name: 'Dismiss', exact: true })
        .or(releasePage.getByRole('link', { name: 'Dismiss', exact: true }))
        .or(releasePage.getByText('Dismiss', { exact: true }))
        .filter({ visible: true }).first();
    await page.addLocatorHandler(releaseDismiss, async button => {
        try {
            await button.click({ timeout: 5_000 });
        } catch (error) {
            if (!(error instanceof errors.TimeoutError) || page.isClosed() || await button.isVisible()) throw error;
            log('Release Notes disappeared before dismissal.');
        }
    });

    // ------------------------------------------------------------
    // STEP 2: Handle "Public User" modal (The popup that blocks the screen)
    // ------------------------------------------------------------
    log("[STEP] Clicking 'Public User' button...");
    try {
        // first wait for the button 
        await page.getByText('Public User', { exact: true }).first().waitFor({ state: 'visible', timeout: 10000 });
        // The button IS there, just use force: true to click it immediately
        await page.getByText('Public User', { exact: true }).first().click({ timeout: 10000, force: true });
        log("[INFO] 'Public User' button clicked successfully!");    
    } catch (error) {
        if (!(error instanceof errors.TimeoutError) || page.isClosed() ||
            await page.getByText('Public User', { exact: true }).first().isVisible() ||
            await releaseDismiss.isVisible()) throw error;
        // The Public User prompt is optional.
        log("[INFO] 'Public User' button didn't appear. Skipping.");
    }

    // ------------------------------------------------------------
    // STEP 4: Navigate to Commercial Pumps
    // ------------------------------------------------------------
    log("[STEP] Selecting Commercial Pumps...");
    await selectCommercialPumps(page);

    // ------------------------------------------------------------
    // STEP 5: Click "Go" button
    // ------------------------------------------------------------
    log("[STEP] Clicking 'Go' button...");
    await page.getByText('Go', { exact: true }).click();

    // ------------------------------------------------------------
    // STEP 6: Fill in Flow and Head (Keep ALL pumps selected)
    // ------------------------------------------------------------
    log(`[STEP] Filling in Flow=${FLOW_VALUE}, Head=${HEAD_VALUE}...`);
    await page.getByLabel('Total System Flow').fill(FLOW_VALUE); // Find input by label text and type 500
    await page.getByLabel('System Head').fill(HEAD_VALUE);        // Find input by label text and type 100
    await page.keyboard.press("Tab");                        // Tab out so the UI updates (activates "Get Results")

    // ------------------------------------------------------------
    // STEP 7: Prepare per-test output paths to avoid collisions between concurrent runs
    // ------------------------------------------------------------
    const getResultsPath = testInfo.outputPath('multi-curves-get-results.json');
    const showCurvesPath = testInfo.outputPath('multi-curves-show-curves.json');

    // ------------------------------------------------------------
    // STEP 8: Click "Get Results" and CAPTURE the API response
    // ------------------------------------------------------------
    log("[STEP] Clicking 'Get Results' button...");
    // CRITICAL: We must SET UP the waitForResponse BEFORE clicking the button.
    const getResultsPromise = page.waitForResponse('**/ButtonClick');
    log("[API] Waiting for endpoint: **/ButtonClick");
    // This sets up a "listener" for any API call matching "**/ButtonClick" (the Get Results API).
    
    await page.getByText('Get Results', { exact: true }).click();
    // Now we click "Get Results". The API call fires immediately.
    
    const getResultsResponse = await getResultsPromise;
    // `await` blocks until the API call completes, then grabs the response.
    log(`[API] ✅ Received response from: ${getResultsResponse.url()}`);
    // Log the FULL URL of the API endpoint
    
    const getResultsJson = await getResultsResponse.json();
    // Convert the raw response into a JavaScript object (JSON).

    // ------------------------------------------------------------
    // STEP 9: Save the Grid data to a file
    // ------------------------------------------------------------
    fs.writeFileSync(getResultsPath, JSON.stringify(getResultsJson, null, 2));
    log(`📁 SAVED: ${getResultsPath}`);

    // ------------------------------------------------------------
    // STEP 10: Capture the "Get Curve" API (The Show Curves response)
    // ------------------------------------------------------------
    log("[STEP] Preparing to intercept 'Get Curve' API...");
    // CRITICAL: Set up the waitForResponse BEFORE clicking "Show Curves" again!
    const getCurveResponsePromise = page.waitForResponse('**/GetCurveResultEx');
    log("[API] Waiting for endpoint: **/GetCurveResultEx");
    
    log("[STEP] Clicking 'Show Curves' button...");
    await page.getByText('Show Curves', { exact: true }).first().click();
    // Click the visible text "Show Curves".
    
    const getCurveResponse = await getCurveResponsePromise;
    // Wait for the API call to come back.
    log(`[API] ✅ Received response from: ${getCurveResponse.url()}`);
    // Log the FULL URL of the API endpoint
    
    const getCurveJson = await getCurveResponse.json();
    // Convert response to a JavaScript object.

    // ------------------------------------------------------------
    // STEP 11: Save the Curve data to a file
    // ------------------------------------------------------------
    fs.writeFileSync(showCurvesPath, JSON.stringify(getCurveJson, null, 2));
    log(`📁 SAVED: ${showCurvesPath}`);

    let curveData: CurveData = {
        // Create a structure to hold the curve data
        title: getCurveJson.title,
        subTitle: getCurveJson.subTitle,
        curveSeries: getCurveJson.curveSeries
    };

    // ------------------------------------------------------------
    // STEP 11.5: Click "Show More Results" to load all rows
    // ------------------------------------------------------------
    log("[STEP] Clicking 'Show More Results' button...");
    const rankCells = page.locator('table:visible tbody tr td:nth-child(2)');
    await expect(rankCells.first()).toBeVisible();
    const showMoreButton = page.getByText('Show More Results').first();
    if (await showMoreButton.isVisible().catch(() => false)) {
        await showMoreButton.click();
        await expect(page.getByText('Show Less Results', { exact: true }).first()).toBeVisible();
        log("[INFO] Clicked 'Show More Results' button");
    } else {
        log("[INFO] 'Show More Results' button not found - all rows already loaded");
    }

    // ------------------------------------------------------------
    // STEP 12: Count total rows DYNAMICALLY (by finding max rank)
    // ------------------------------------------------------------
    log("[STEP] Counting total rows...");

    // Get ALL rank cells from the table (2nd column)
    const rankTexts = await rankCells.allTextContents();
    //log(`[INFO] Raw rank cells: ${JSON.stringify(rankTexts)}`);

    // Convert to numbers and filter out NaN
    const rankNumbers = rankTexts.map(cell => parseInt(cell.trim())).filter(num => !isNaN(num));
    log(`[INFO] Rank numbers found: ${JSON.stringify(rankNumbers)}`);

    // ✅ FIX: Use the length of the array (actual row count), NOT the max rank
    const totalRows = rankNumbers.length;
    log(`[INFO] Found ${totalRows} actual rows in the grid`);

    // ------------------------------------------------------------
    // STEP 12.5: Wait for ALL curve images to appear (TRULY ASYNCHRONOUSLY)
    // ------------------------------------------------------------
    log("[STEP] Waiting for all curves to generate...");
    
    // Initialize results array
    const results: RowResult[] = [];
    const startTime = Date.now();

    // Create an array of promises - one for each row (ALL run in parallel)
    const rowPromises = Array.from({ length: totalRows }, (_, i) => {
        return (async () => {
            const rowStart = Date.now();
            
            try {
                // ✅ FIX: Use the "Full Screen Curve" link locator that actually exists
                await page.getByRole('link', { name: 'Full Screen Curve' }).nth(i).waitFor({ 
                    state: 'visible', 
                    timeout: MAX_WAIT_SECONDS * 1000 
                });
                const elapsed = (Date.now() - rowStart) / 1000;
                return { row: i + 1, status: '✅ PASSED', time: elapsed };
            } catch {
                const elapsed = (Date.now() - rowStart) / 1000;
                return { row: i + 1, status: '❌ FAILED', time: elapsed };
            }
        })();
    });

    // Wait for ALL promises to complete (in parallel)
    const settledResults = await Promise.all(rowPromises);

    // Sort results by time (fastest first) - shows TRUE completion order
    results.push(...settledResults.sort((a, b) => a.time - b.time));

    // Print results in TRUE completion order
    results.forEach(r => {
        log(`[ROW ${r.row}] ${r.status} (${r.time.toFixed(1)}s)`);
    });

    // ------------------------------------------------------------
    // STEP 13: Final Summary
    // ------------------------------------------------------------
    const passed = results.filter(r => r.status === '✅ PASSED').length;
    const failed = results.filter(r => r.status === '❌ FAILED').length;
    const totalTime = ((Date.now() - startTime) / 1000).toFixed(1);
    
    log(`\n[RESULT] ${passed} out of ${totalRows} passed (${failed} failed)`);
    log(`[TIME] Total time: ${totalTime}s`);

    // ------------------------------------------------------------
    // STEP 14: Assertions (The "Pass/Fail" check)
    // ------------------------------------------------------------
    expect(passed).toBeGreaterThan(0); // At least 1 curve should pass
    expect(failed).toBe(0); // No curves should fail (or adjust as needed)

    // ------------------------------------------------------------
    // STEP 15: ATTACH CONSOLE OUTPUT TO HTML REPORT
    // ------------------------------------------------------------
    // Convert the array to a string and attach it as a text file
    const consoleOutputText = consoleOutput.join('\n');
    await testInfo.attach('console-output.txt', {
        body: Buffer.from(consoleOutputText, 'utf-8'),
        contentType: 'text/plain'
    });
    log("📎 Attached console output to HTML report");

});