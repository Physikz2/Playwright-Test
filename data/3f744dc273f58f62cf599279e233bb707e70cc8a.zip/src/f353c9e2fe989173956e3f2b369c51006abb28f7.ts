import { open, writeFile } from 'node:fs/promises';
import { errors, expect, test, type Locator, type Page, type TestInfo } from '@playwright/test';
import { getAdeptPumpSettings, getAdeptTestEmail } from '../config/adept';

// Keep JSON files in test-results and optionally attach them to the HTML report.
async function saveJson(testInfo: TestInfo, name: string, data: unknown, attach: boolean): Promise<void> {
  const file = testInfo.outputPath(`${name}.json`);
  await writeFile(file, JSON.stringify(data, null, 2));
  if (attach) await testInfo.attach(`${name}.json`, { path: file, contentType: 'application/json' });
}

// Save the currently displayed matrix and log its product count.
// The initial, expanded, and active views are saved separately in test-results.
async function saveMatrix(table: Locator, testInfo: TestInfo, name: string, attach: boolean): Promise<void> {
  const matrix = await table.evaluate(element => ({
    columns: Array.from(element.querySelectorAll('thead th'), cell => cell.textContent?.trim() ?? ''),
    rows: Array.from(element.querySelectorAll('tbody tr'), row =>
      Array.from(row.querySelectorAll('td'), cell => cell.textContent?.trim() ?? '')),
  }));
  expect(matrix.rows.length, `${name} must contain products`).toBeGreaterThan(0);
  await saveJson(testInfo, name, matrix, attach);
  console.log(`${name}: ${matrix.rows.length} displayed products`);
}

// ADEPT can rebuild custom controls while tab content or generated documents are loading.
async function selectOption(page: Page, title: string): Promise<void> {
  const checkbox = page.locator('saa-check-box').filter({ visible: true })
    .filter({ has: page.getByText(title, { exact: true }) });
  const option = checkbox.locator('input[type="checkbox"]');

  for (let attempt = 1; attempt <= 3; attempt++) {
    await expect(checkbox).toBeVisible();
    await expect(option).toBeEnabled();
    if (!await option.isChecked()) {
      await checkbox.locator('label.text').click();
    }
    try {
      await expect(option).toBeChecked({ timeout: 5_000 });
      return;
    } catch (error) {
      if (attempt === 3) throw error;
      console.log(`${title} was rebuilt during selection; retrying (${attempt}/3).`);
    }
  }
}

// ADEPT can close or rebuild the category menu while it is still loading.
async function selectCommercialPumps(page: Page): Promise<void> {
  const category = page.getByLabel('Select box activate');
  const commercialPumps = page.getByRole('link', { name: 'Commercial Pumps', exact: true });

  for (let attempt = 1; attempt <= 4; attempt++) {
    try {
      // The toggle is hidden while the menu is open; do not close an open menu.
      if (await category.isVisible()) await category.click({ timeout: 5_000 });
      await commercialPumps.click({ timeout: 5_000 });
      return;
    } catch (error) {
      if (!(error instanceof errors.TimeoutError) || attempt === 4) throw error;
      console.log(`Category selection not ready; retrying (${attempt}/4).`);
    }
  }
}

// Some result sets do not offer the active-pump filter.
async function setActiveFilter(active: Locator, enabled: boolean): Promise<boolean> {
  if (!await active.isVisible()) return false;
  const isActive = (await active.getAttribute('class'))?.split(/\s+/).includes('active') ?? false;
  if (isActive !== enabled) await active.click();
  if (enabled) {
    await expect(active).toHaveClass(/(?:^|\s)active(?:\s|$)/);
  } else {
    await expect(active).not.toHaveClass(/(?:^|\s)active(?:\s|$)/);
  }
  return true;
}

// ADEPT public selection: find a pump, select accessories, and prepare its documents.
// This workflow can send a real email and adds a selection to a schedule.
test('selects a pump and prepares its documents and schedule', async ({ page }, testInfo) => {
  test.setTimeout(300_000);
  // Select LNTEST or production, JSON attachments, and email in the ignored local config.
  const { attachJson, sendEmail, environment, url } = getAdeptPumpSettings();
  console.log(`Pump environment: ${environment} (${url})`);
  const email = sendEmail ? getAdeptTestEmail() : null;

  // Register once: cancel optional pump warnings when they appear during later actions.
  const pumpWarning = page.locator('.popup-warning-curve-view:visible');
  const dismissPumpWarning = async (warning: Locator): Promise<void> => {
    await warning.getByText('Cancel', { exact: true }).click();
  };
  await page.addLocatorHandler(pumpWarning, dismissPumpWarning);

  // 1. Open ADEPT as a Public User and wait for the product selection session.
  // Register the response wait before navigation so the initialization is not missed.
  // API 1: POST ProductSelection/Session initializes the selection session.
  const initialSession = page.waitForResponse(response =>
    new URL(response.url()).pathname.toLowerCase().endsWith('/productselection/session')
      && response.request().method() === 'POST', { timeout: 60_000 });
  await page.goto(url);
  // WalkMe places the clickable shape over the Public User button.
  await page.getByRole('button', { name: 'Public User', exact: true })
    .locator('..').locator('.wm-visual-design-shape').click();
  expect((await initialSession).ok(), 'Product selection session should initialize').toBeTruthy();

  // 2. Choose Commercial Pumps, click Go, and wait for the pump options to load.
  await selectCommercialPumps(page);
  // API 2: POST Pumps/Pumps loads the available pump options after Go.
  const pumpOptions = page.waitForResponse(response =>
    new URL(response.url()).pathname.endsWith('/Pumps/Pumps')
      && response.request().method() === 'POST', { timeout: 60_000 });
  await page.getByText('Go', { exact: true }).click();
  expect((await pumpOptions).ok(), 'Pump options should load').toBeTruthy();

  // 3. Confirm Design Envelope is the preselected product.
  await expect(page.getByRole('button', { name: 'Select A Product' })).toContainText('Design Envelope');

  // 4. Set flow to 1000 and head to 100; Tab applies the value in ADEPT.
  // Keep Select All checked so the search includes all pump series.
  await page.getByRole('spinbutton', { name: 'Total System Flow' }).fill('1000');
  await page.getByRole('spinbutton', { name: 'System Head' }).fill('100');
  await page.getByRole('spinbutton', { name: 'System Head' }).press('Tab');
  const selectAll = page.locator('input[data-control-title="Select All"]');
  if (!await selectAll.isChecked()) {
    await page.getByText('Select All', { exact: true }).click();
  }
  await expect(selectAll).toBeChecked();

  // 5. Click Get Results and save the search API response for later inspection.
  // Start the response wait first because the request can finish immediately.
  // API 3: POST SelectionOptimizationService/Search returns the pump search data.
  const searchResponse = page.waitForResponse(response =>
    new URL(response.url()).pathname.endsWith('/SelectionOptimizationService/Search')
      && response.request().method() === 'POST', { timeout: 90_000 });
  await page.getByText('Get Results', { exact: true }).first().click();
  const response = await searchResponse;
  expect(response.ok(), 'Pump search API should succeed').toBeTruthy();
  await saveJson(testInfo, 'pump-search-api', await response.json(), attachJson);

  // 6. Save and count the initially displayed matrix, then expand and save it again.
  // ADEPT may default to active pumps only, so turn that filter off if available.
  const table = page.locator('table:visible').first();
  await expect(table.locator('tbody tr').first()).toBeVisible({ timeout: 90_000 });
  const active = page.getByText('Show Only Active', { exact: true }).filter({ visible: true }).first();
  console.log(`Show Only Active button: ${await active.isVisible() ? 'visible' : 'not visible'}.`);
  await setActiveFilter(active, false);
  await saveMatrix(table, testInfo, 'pump-results-initial', attachJson);
  await page.getByText('Show More Results', { exact: true }).first().click();
  await expect(page.getByText('Show Less Results', { exact: true }).first()).toBeVisible();
  await saveMatrix(table, testInfo, 'pump-results-expanded', attachJson);

  // 7. Save the active-only matrix if ADEPT offers the filter.
  if (await setActiveFilter(active, true)) {
    await saveMatrix(table, testInfo, 'pump-results-active', attachJson);
  } else {
    console.log('Show Only Active is unavailable; continuing with the displayed results.');
  }

  // 8. Select the first model; the warning handler cancels any warning popup.
  await table.locator('tbody tr').first().locator('.saa-table-cell-action').first().click();
  const postSelect = page.locator('#PostSelectPage_');
  const curve = postSelect.locator('canvas.base').first();

  // 9. Dismiss warnings independently while waiting for the curve pixels to stabilize.
  // Verify the flow and head fields still contain the requested operating point.
  await page.removeLocatorHandler(pumpWarning);
  try {
    await expect(curve).toBeVisible({ timeout: 90_000 });
    let previousPixels: string | null = null;
    let hasDrawnPixels = false;
    await expect.poll(async () => {
      if (await pumpWarning.isVisible()) {
        await dismissPumpWarning(pumpWarning);
        await expect(pumpWarning).toBeHidden({ timeout: 5_000 });
        previousPixels = null;
      }
      const pixels = await curve.evaluate(canvas => {
        const element = canvas as HTMLCanvasElement;
        const context = element.getContext('2d');
        if (!context || !element.width || !element.height) return null;
        const data = context.getImageData(0, 0, element.width, element.height).data;
        if (!data.some((value, index) => index % 4 === 3 && value > 0)) return null;
        return element.toDataURL();
      });
      hasDrawnPixels = pixels !== null;
      const stable = hasDrawnPixels && pixels === previousPixels;
      previousPixels = pixels;
      return stable;
    }, { message: 'Single-curve canvas should have stable drawn pixels', intervals: [300], timeout: 15_000 }).toBe(true);
    expect(hasDrawnPixels, 'Single-curve canvas should contain drawn pixels').toBe(true);
  } finally {
    await page.addLocatorHandler(pumpWarning, dismissPumpWarning);
  }
  await expect(page.getByRole('spinbutton', { name: 'Flow', exact: true })).toHaveValue('1000');
  await expect(page.getByRole('spinbutton', { name: 'Head', exact: true })).toHaveValue('100');

  // 10. Verify the left-hand pump details and that its pump image has loaded.
  await expect(postSelect).toContainText('1000 USgpm');
  await expect(postSelect).toContainText('100 ft');
  const pumpImage = postSelect.locator('img').first();
  await expect(pumpImage).toBeVisible();
  await expect.poll(() => pumpImage.evaluate(image => (image as HTMLImageElement).naturalWidth)).toBeGreaterThan(0);

  // 11. Open Multi-Curve and check its recorded overlay is visible.
  await page.getByRole('link', { name: 'Multi-Curve' }).click();
  await expect(page.locator('.nonClickableOverlay')).toBeVisible();

  // 12. Open Line Drawing and check the drawing is visible.
  await page.getByRole('link', { name: 'Line Drawing' }).click();
  await expect(page.locator('.line-drawing-image')).toBeVisible();

  // 13. Open Options and check the three recorded images are visible.
  await page.getByRole('link', { name: 'Options', exact: true }).click();
  await expect(page.locator('.options-image:visible')).toHaveCount(3);

  // 14. Add a suction guide, get results, and select the first matching model.
  // The yellow schedule button is disabled until the accessory model is selected.
  await page.getByRole('link', { name: 'Accessories' }).click();
  const schedule = page.locator('.button-circle.add-button');
  const suction = postSelect.locator('.product-options-layout').filter({ hasText: 'Add Suction Guide' });
  await selectOption(page, 'Add Suction Guide');
  await expect(schedule).toHaveClass(/disabled/);
  await suction.getByText('Get Results', { exact: true }).click();
  await suction.getByText('SG-', { exact: false }).first().click();
  await expect(postSelect).toContainText('Suction Guide');
  await expect(schedule).not.toHaveClass(/disabled/, { timeout: 90_000 });

  // 15. Add a Flo-Trex valve, get results, and select the first matching model.
  // Again, wait for the schedule button to become available after selection.
  const valve = postSelect.locator('.product-options-layout').filter({ hasText: 'Add Flo-Trex Valve' });
  await selectOption(page, 'Add Flo-Trex Valve');
  await expect(schedule).toHaveClass(/disabled/);
  await valve.getByText('Get Results', { exact: true }).click();
  await valve.getByText('FTV-', { exact: false }).first().click();
  await expect(postSelect).toContainText('FloTrex Valve');
  await expect(schedule).not.toHaveClass(/disabled/, { timeout: 90_000 });

  // 16. Add "testing" to the external comments.
  await page.getByRole('link', { name: 'Additional Information' }).click();
  await page.getByRole('textbox', { name: 'External Comments (to be' }).fill('testing');

  if (email !== null) {
    // 17. Open Email, enter the recipient, and Tab out to trigger validation.
    await page.locator('#email-icon').click();
    const emailInput = page.getByRole('textbox', { name: 'Email Address*' });
    await emailInput.fill(email);
    await emailInput.press('Tab');

    // 18. Include Submittal and Specification PDFs, then send the email.
    // Wait for document generation to finish before opening Download.
    await page.getByRole('link', { name: 'Inclusion' }).click();
    await selectOption(page, 'Submittal (PDF)');
    await selectOption(page, 'Specification (PDF)');
    // API 4: POST ButtonClick completes the email document-generation request.
    const emailResponse = page.waitForResponse(response =>
      new URL(response.url()).pathname.endsWith('/ButtonClick')
        && response.request().method() === 'POST', { timeout: 150_000 });
    await page.getByText('Send', { exact: true }).click({ timeout: 90_000 });
    expect((await emailResponse).ok(), 'Email generation should succeed').toBeTruthy();
  } else {
    console.log('Email skipped: pumpSendEmail is false.');
  }

  // 19. Select the three requested PDFs and download them as a ZIP.
  // Check its size and ZIP signature; register the download wait before clicking.
  await page.locator('#download').click();
  await expect(page.getByText('Begin Download', { exact: true })).toBeVisible({ timeout: 90_000 });
  await selectOption(page, 'Submittal (PDF)');
  await selectOption(page, 'Specification (PDF)');
  await selectOption(page, 'Single Curve (PDF)');
  const downloadPromise = page.waitForEvent('download', { timeout: 90_000 });
  await page.getByText('Begin Download', { exact: true }).click();
  const download = await downloadPromise;
  const file = await open(await download.path(), 'r');
  try {
    const size = (await file.stat()).size;
    expect(size, 'ZIP download must not be empty').toBeGreaterThan(0);
    const signature = Buffer.alloc(4);
    await file.read(signature, 0, signature.length, 0);
    expect(signature.equals(Buffer.from([0x50, 0x4b, 0x03, 0x04])), 'Download must be a ZIP').toBe(true);
    console.log(`ZIP download: ${size} bytes`);
  } finally {
    await file.close();
  }

  // 20. Click the yellow schedule button, finish, and verify the pump appears.
  await schedule.locator('.button-anchor').click();
  await page.getByText('Finish', { exact: true }).click({ timeout: 90_000 });
  await expect(page.locator('tbody').filter({ hasText: 'Commercial Pumps - Design Envelope' }).first())
    .toBeVisible({ timeout: 90_000 });
});
