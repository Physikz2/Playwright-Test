import { errors, expect, type Locator, type Page } from '@playwright/test';

export async function clickItemOption(
  page: Page,
  itemOption: Locator,
  searchInput: Locator,
  searchText: string,
  expectedItem: RegExp,
  forbiddenItem?: RegExp,
): Promise<void> {
  for (let attempt = 1; attempt <= 3; attempt++) {
    if (attempt > 1) await searchInput.clear();
    await searchInput.fill(searchText);
    try {
      await itemOption.waitFor({ state: 'visible', timeout: 10_000 });
      // Playwright's click waits for the current option to be enabled, stable and unobstructed.
      await itemOption.click({ timeout: 5_000 });
    } catch (error) {
      const transient = error instanceof errors.TimeoutError ||
        (error instanceof Error && /element (?:is |was )?(?:not attached|detached)/i.test(error.message));
      if (!transient || attempt === 3) throw error;
      console.warn(`Item option was interrupted; retrying (${attempt}/3): ${String(error).split('\n')[0]}`);
      continue;
    }

    try {
      if (forbiddenItem) {
        await expect(searchInput).not.toHaveValue(forbiddenItem, { timeout: 5_000 });
      }
      await expect(searchInput).toHaveValue(expectedItem, { timeout: 5_000 });
      return;
    } catch (error) {
      if (page.isClosed() || !await searchInput.isVisible()) throw error;
      const actual = await searchInput.inputValue({ timeout: 5_000 });
      const matchesExpected = new RegExp(expectedItem.source, expectedItem.flags).test(actual);
      const matchesForbidden = forbiddenItem !== undefined &&
        new RegExp(forbiddenItem.source, forbiddenItem.flags).test(actual);
      if (matchesExpected && !matchesForbidden) throw error;
      if (attempt === 3) {
        const visibleItems = await page.locator('li.rcbItem').filter({ visible: true }).allInnerTexts();
        throw new Error(
          `Unable to select the requested item after ${attempt} attempts. ` +
          `Actual Item input: ${JSON.stringify(actual)}; visible dropdown items: ${JSON.stringify(visibleItems)}.`,
        );
      }
      console.warn(`Wrong item selected (${actual}); retrying (${attempt}/3).`);
    }
  }
}
