import { errors, expect, type FrameLocator, type Locator, type Page } from '@playwright/test';

type GuidanceRoot = Page | FrameLocator;

export const calendarTrigger = (input: Locator) =>
  input.locator('..').getByRole('img', { name: 'Select a Date' });

export const dateValue = (date: Date) => `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;

export function getNextWeekdayOneWeekOut(): Date {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() + 7);
  if (date.getDay() === 6) date.setDate(date.getDate() + 2);
  else if (date.getDay() === 0) date.setDate(date.getDate() + 1);
  return date;
}

export async function orderPageStatus(page: Page): Promise<string> {
  if (page.isClosed()) return `URL: ${page.url()}; page closed`;
  const state = await page.evaluate(() => {
    const visible = (element: Element) => {
      const style = window.getComputedStyle(element);
      return style.visibility !== 'hidden' && style.display !== 'none' && element.getClientRects().length > 0;
    };
    const frames = [...document.querySelectorAll('iframe.ui-corner-bottom[frameborder="0"]')].filter(visible).length;
    const quote = [...document.querySelectorAll('h1, h2')].some(element =>
      visible(element) && /^quote$/i.test(element.textContent?.trim() ?? ''));
    const dialogs = [...document.querySelectorAll(
      '.ui-dialog, [role="dialog"], [role="alert"], [aria-modal="true"], .alert, .warning, .validation-summary-errors',
    )]
      .filter(visible)
      .map(element => (element.textContent ?? '').replace(/\s+/g, ' ').trim().slice(0, 160))
      .filter(Boolean)
      .slice(0, 3);
    return { frames, quote, dialogs };
  });
  return `URL: ${page.url()}; visible Order Header frame candidates: ${state.frames}; ` +
    `quote view: ${state.quote ? 'visible' : 'not visible'}; ` +
    `visible dialogs/alerts: ${state.dialogs.length ? state.dialogs.join(' | ') : 'none'}`;
}

export async function waitForOrderHeader(page: Page, timeout = 30_000): Promise<FrameLocator> {
  const frame = page.locator('iframe.ui-corner-bottom[frameborder="0"]:visible');
  const order = page.frameLocator('iframe.ui-corner-bottom[frameborder="0"]:visible');
  try {
    await expect(frame).toBeVisible({ timeout });
    await expect(order.locator('#orderHeaderCtl_txtMfgPONumber')).toBeVisible({ timeout });
  } catch (error) {
    let status: string;
    try {
      status = await orderPageStatus(page);
    } catch (diagnosticError) {
      status = `URL: ${page.url()}; state unavailable: ${String(diagnosticError)}`;
    }
    throw new Error(
      `Order Header frame or PO Number input did not become visible after page-level Place Order. ` +
      `Check for an ARM/approval warning or an unchanged quote/stock-retrieval view. ${status}\n` +
      `Readiness error: ${String(error)}`,
    );
  }
  return order;
}

export async function dismissTutorials(root: GuidanceRoot): Promise<void> {
  const close = root.locator(
    '[title="Stop Walk-thru"], [aria-label*="close" i], [aria-label*="dismiss" i], ' +
    'button:has-text("Close"), button:has-text("Skip")',
  ).and(root.locator(':not(.ui-dialog-titlebar-close, .ui-dialog-titlebar-close *)'))
    .filter({ visible: true }).first();
  if (!await close.isVisible()) return;
  try {
    await close.click({ timeout: 5_000, noWaitAfter: true });
  } catch (error) {
    if (!(error instanceof errors.TimeoutError)) throw error;
    if (await close.isVisible()) console.warn('Tutorial close control could not be clicked within 5 seconds.');
  }
}

const monthNames = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

export async function selectCalendarDate(
  trigger: Locator,
  calendar: Locator,
  date: Date,
  options: { nextAvailable?: boolean } = {},
): Promise<Date> {
  await trigger.click({ timeout: 30_000 });
  await expect(calendar).toBeVisible({ timeout: 30_000 });

  const candidate = new Date(date);
  candidate.setHours(0, 0, 0, 0);
  const displayedMonth = async () => {
    const [monthName, yearText] = await calendar.locator('.ui-datepicker-month, .ui-datepicker-year').allTextContents();
    const month = monthNames.indexOf(monthName?.trim());
    const year = Number(yearText?.trim());
    if (month < 0 || !Number.isInteger(year) || year < 1) {
      throw new Error(`Unexpected calendar month/year: ${monthName} ${yearText}`);
    }
    return year * 12 + month;
  };
  let currentMonth = await displayedMonth();
  let navigationSteps = 0;
  for (let offset = 0; offset <= 366; offset++, candidate.setDate(candidate.getDate() + 1)) {
    const targetMonth = candidate.getFullYear() * 12 + candidate.getMonth();
    while (currentMonth !== targetMonth) {
      if (++navigationSteps > 24) {
        throw new Error(`Calendar could not reach ${candidate.toLocaleDateString()} within 24 months.`);
      }
      const direction = currentMonth < targetMonth ? 'next' : 'prev';
      await calendar.locator(`.ui-datepicker-${direction}`).click({ timeout: 30_000 });
      currentMonth = await displayedMonth();
    }

    const day = String(candidate.getDate());
    const cell = calendar.locator('td:not(.ui-datepicker-other-month)')
      .filter({ hasText: new RegExp(`^\\s*${day}\\s*$`) });
    const disabled = cell.and(calendar.locator('td.ui-datepicker-unselectable, td.ui-state-disabled, td[aria-disabled="true"]'));
    if (options.nextAvailable && await disabled.count()) {
      continue;
    }

    const link = cell.getByRole('link', { name: day, exact: true });
    try {
      await link.click({ timeout: 5_000 });
    } catch (error) {
      if (!(error instanceof errors.TimeoutError)) throw error;
      const unavailable = await disabled.count() > 0 || await link.count() === 0 ||
        await link.and(calendar.locator('[aria-disabled="true"], .ui-state-disabled')).count() > 0;
      if (!unavailable) throw error;
      if (options.nextAvailable) continue;
      throw new Error(`Calendar date ${candidate.toLocaleDateString()} is unavailable.`);
    }
    if (offset > 0) {
      console.warn(`Requested ship date ${date.toLocaleDateString()} was unavailable; selected ${candidate.toLocaleDateString()}.`);
    }
    return candidate;
  }
  throw new Error(`No available calendar date within a year of ${date.toLocaleDateString()}.`);
}

export async function selectVerifiedCalendarDate(
  input: Locator,
  trigger: Locator,
  calendar: Locator,
  date: Date,
): Promise<void> {
  await selectCalendarDate(trigger, calendar, date);
  await input.press('Tab', { timeout: 5_000 });
  await expect(input).toHaveValue(dateValue(date), { timeout: 5_000 });
}
