import { randomInt } from 'node:crypto';
import { errors, expect, test, type Locator, type Page } from '@playwright/test';
import { getAdeptConfig } from '../config/adept';
import { clickItemOption } from '../helpers/itemSelection';
import {
  calendarTrigger,
  dateValue,
  getNextWeekdayOneWeekOut,
  selectCalendarDate,
  selectVerifiedCalendarDate,
} from '../helpers/orderModal';
import { normalizePricingTotal } from '../helpers/pricing';
import { openOrderHeader, waitForQuoteLine } from '../helpers/stockRetrieval';
import { dismissExpediteAlertIfPresent, dismissReleaseNotesIfPresent } from '../helpers/walkMe';

// WalkMe may remove an overlay while its dismissal click is being prepared.
async function dismissWalkMeOverlay(page: Page, button: Locator): Promise<void> {
  if (!await button.isVisible()) return;
  try {
    await button.click({ timeout: 5_000 });
  } catch (error) {
    if (!(error instanceof errors.TimeoutError) || page.isClosed() || await button.isVisible()) throw error;
    console.log('WalkMe overlay disappeared before it could be dismissed.');
  }
}

// Re-dismiss month-specific Release Notes if they reappear during later actions.
async function handleRecurringReleaseNotes(page: Page): Promise<void> {
  // WalkMe can prefix the title with an invisible whitespace character.
  const title = page.getByText(
    /^\s*(?:January|February|March|April|May|June|July|August|September|October|November|December)(?:\s+\d{4})?\s+Release(?:\s+Notes)?\s*$/i,
  ).filter({ visible: true });
  const releasePage = page.locator('body').filter({ has: title });
  // Match a visible Dismiss control only when the Release Notes title is present.
  const dismiss = releasePage.getByRole('button', { name: 'Dismiss', exact: true })
    .or(releasePage.getByRole('link', { name: 'Dismiss', exact: true }))
    .or(releasePage.getByText('Dismiss', { exact: true }))
    .filter({ visible: true }).first();

  // Playwright runs the handler during action checks and waits for the popup to disappear.
  await page.addLocatorHandler(dismiss, async button => {
    await dismissWalkMeOverlay(page, button);
  });
}

// Close visible WalkMe help balloons without closing application dialogs.
async function handleWalkthroughs(page: Page): Promise<void> {
  const close = page.locator('[title="Stop Walk-thru" i], .walkme-custom-balloon-close-button')
    .filter({ visible: true }).first();

  await page.addLocatorHandler(close, async button => {
    await dismissWalkMeOverlay(page, button);
  });
}

// Start listening for browser dialogs before clicking, but wait for an in-page
// confirmation only after the click so its locator cannot race the WalkMe handler.
async function confirmStockRetrieval(page: Page, placeOrder: Locator, stockMessage: Locator): Promise<void> {
  const pending = new AbortController();
  const browserDialog = page.waitForEvent('dialog', { timeout: 0, signal: pending.signal })
    .then(async dialog => {
      if (!/check stock has been retrieved|try placing order again/i.test(dialog.message())) {
        await dialog.dismiss();
        throw new Error(`Unexpected browser dialog during stock retrieval: ${dialog.message()}`);
      }
      await Promise.all([
        page.waitForEvent('framenavigated', {
          predicate: frame => frame === page.mainFrame(), timeout: 60_000, signal: pending.signal,
        }),
        dialog.accept(),
      ]);
      return { kind: 'browser' as const };
    })
    .then(result => result, error => ({ kind: 'error' as const, error }));

  try {
    await placeOrder.click();
    const modal = stockMessage.waitFor({ state: 'visible', timeout: 45_000, signal: pending.signal })
      .then(() => ({ kind: 'modal' as const }));
    const confirmation = await Promise.race([modal, browserDialog]);
    pending.abort();
    if (confirmation.kind === 'error') throw confirmation.error;
    if (confirmation.kind === 'modal') {
      const dialog = stockMessage.locator(
        'xpath=ancestor-or-self::*[contains(concat(" ", normalize-space(@class), " "), " ui-dialog ") or ' +
        '@role="dialog" or @aria-modal="true" or ' +
        'contains(concat(" ", normalize-space(@class), " "), " modal ")][1]',
      );
      await Promise.all([
        page.waitForEvent('framenavigated', { predicate: frame => frame === page.mainFrame(), timeout: 60_000 }),
        dialog.getByRole('button', { name: 'OK', exact: true }).click(),
      ]);
    }
  } finally {
    pending.abort();
  }
}

// A ship-date calendar can open after the requested month when earlier dates are unavailable.
async function selectRequestedShipDate(input: Locator, calendar: Locator, requested: Date): Promise<Date> {
  await input.click({ timeout: 30_000 });
  await expect(calendar).toBeVisible({ timeout: 30_000 });
  const displayedMonth = async (): Promise<Date> => {
    const [month, year] = await calendar.locator('.ui-datepicker-month, .ui-datepicker-year').allTextContents();
    const displayed = new Date(`${month?.trim()} 1, ${year?.trim()}`);
    if (!Number.isFinite(displayed.getTime())) throw new Error(`Unexpected calendar month/year: ${month} ${year}`);
    return displayed;
  };
  const monthIndex = (date: Date) => date.getFullYear() * 12 + date.getMonth();
  let shown = await displayedMonth();
  let start = new Date(requested);
  let navigationSteps = 0;
  while (monthIndex(shown) > monthIndex(start)) {
    const previous = calendar.locator('.ui-datepicker-prev');
    const disabled = await previous.evaluate(element =>
      element.matches('.ui-state-disabled, [aria-disabled="true"], [disabled]'));
    if (disabled) {
      start = new Date(shown.getFullYear(), shown.getMonth(), 1);
      console.warn(`Requested ship date ${dateValue(requested)} is before the earliest available calendar month.`);
      break;
    }
    if (++navigationSteps > 24) throw new Error('Ship-date calendar could not reach the requested month within 24 months.');
    const previousMonth = monthIndex(shown);
    await previous.click({ timeout: 30_000 });
    await expect.poll(async () => monthIndex(await displayedMonth()), { timeout: 5_000 }).toBeLessThan(previousMonth);
    shown = await displayedMonth();
  }
  await input.press('Escape');
  await expect(calendar).toBeHidden({ timeout: 5_000 });
  // The field remains focused after Escape; its calendar icon reliably reopens the picker.
  return selectCalendarDate(calendarTrigger(input), calendar, start, { nextAvailable: true });
}

// ADEPT: create a quote, retrieve stock, and submit an order for review.
// This workflow creates application data; credentials and the URL come from configuration.
test('creates a quote and submits an order for review', async ({ page }) => {
  test.setTimeout(180_000);
  const { environment, loginUrl, username, password } = getAdeptConfig();
  console.log(`ADEPT environment: ${environment}`);

  // 1. Sign in with the configured credentials and open the quote page.
  await page.goto(loginUrl);
  await page.getByRole('textbox', { name: 'User ID:' }).fill(username);
  await page.getByRole('textbox', { name: 'Password:' }).fill(password);
  await page.getByRole('button', { name: 'Log On' }).click();

  // 2. Dismiss optional Release Notes and Expedite Alert after login.
  // Register handlers once for Release Notes or WalkMe help that reappear later.
  await dismissReleaseNotesIfPresent(page);
  await handleRecurringReleaseNotes(page);
  await handleWalkthroughs(page);
  await dismissExpediteAlertIfPresent(page);

  // 3. Start a new quote from the page-level navigation.
  await page.getByRole('link', { name: 'New Quote', exact: true }).click();

  // 4. Search for 56, select the exact 425650-000 coupling, and add it.
  // The selection helper checks the resulting value to avoid adding a similarly named item.
  const itemSearch = page.locator('#ctl00_ctl03_itemSelection_itemSelectionDropDown_Input');
  const coupling = page.locator('li.rcbItem', { hasText: /^\s*425650-000 - coupling-split 2-1\/8 x 2-1\/8\s*$/ }).first();
  const itemSelectionTarget = 'ctl00$ctl03$itemSelection$itemSelectionDropDown';
  const selectionResponse = page.waitForResponse(response => {
    const request = response.request();
    if (request.method() !== 'POST' || !new URL(response.url()).pathname.toLowerCase().endsWith('/order.aspx')) return false;
    const form = new URLSearchParams(request.postData() ?? '');
    return form.get('__EVENTTARGET') === itemSelectionTarget &&
      /^\s*425650-000(?:\s|$)/.test(form.get(itemSelectionTarget) ?? '');
  }, { timeout: 30_000 });
  const [selected] = await Promise.all([
    selectionResponse,
    clickItemOption(page, coupling, itemSearch, '56', /^\s*425650-000(?:\s|$)/),
  ]);
  expect(selected.ok(), 'Item selection postback should succeed').toBeTruthy();
  const selectionError = await selected.finished();
  if (selectionError) throw selectionError;

  // ADEPT updates the dropdown asynchronously; wait for its postback before Add can overwrite it.
  await page.waitForFunction(() => {
    const app = window as Window & {
      Sys?: { WebForms?: { PageRequestManager?: { getInstance(): { get_isInAsyncPostBack(): boolean } } } };
    };
    const manager = app.Sys?.WebForms?.PageRequestManager?.getInstance();
    return manager !== undefined && !manager.get_isInAsyncPostBack();
  }, null, { timeout: 30_000 });
  await expect(itemSearch).toHaveValue(/^\s*425650-000(?:\s|$)/);
  await page.getByRole('link', { name: 'Add', exact: true }).click();

  // 5. Name the quote PO; Tab leaves the field so ADEPT can save the value.
  await page.getByRole('textbox', { name: 'Quote Name:' }).fill('PO');
  await page.getByRole('textbox', { name: 'Quote Name:' }).press('Tab');

  // 6. Complete the Header with Apple, a book date at least one week out, and Hartford, CT.
  // Move weekend book dates to Monday and select the date through the calendar.
  await page.getByRole('link', { name: 'Header', exact: true }).click();
  await page.locator('#ctl00_ctl03_sbdOrderHeader_txtCommercialContact').fill('Apple');
  const bookDate = page.locator('#ctl00_ctl03_sbdOrderHeader_dpExpectedBookDate');
  await selectVerifiedCalendarDate(bookDate, calendarTrigger(bookDate), page.locator('#ui-datepicker-div'), getNextWeekdayOneWeekOut());
  await page.locator('#ctl00_ctl03_sbdOrderHeader_SiteAddress_ddlCountry').selectOption({ label: 'United States' });
  await page.locator('#ctl00_ctl03_sbdOrderHeader_SiteAddress_ddlState').selectOption('CT');
  await page.locator('#ctl00_ctl03_sbdOrderHeader_SiteAddress_txtCity').fill('Hartford');
  await page.locator('#ctl00_ctl03_sbdOrderHeader_SiteAddress_txtCity').press('Tab');

  // 7. Open Pricing; the walkthrough handler closes optional help popups.
  // Wait for a positive total and normalize it for the later P.O. Amount field.
  await page.getByRole('link', { name: 'Pricing', exact: true }).click();
  const total = page.locator('#ctl00_ctl03_sbdOrderPricing_lblTotalAmt');
  let poAmount: string | null = null;
  await expect.poll(async () => {
    poAmount = normalizePricingTotal(await total.innerText());
    return poAmount;
  }, { message: 'Pricing total should contain a calculated positive amount', timeout: 60_000 }).not.toBeNull();
  if (poAmount === null) throw new Error('Pricing total was not captured.');

  // 8. The first page-level Place Order retrieves stock rather than placing the order.
  // Confirm the stock message, wait for refresh, and verify the coupling is in quote lines.
  const placeOrder = page.getByRole('link', { name: 'Place Order', exact: true });
  const stockMessage = page.getByText(/check stock has been retrieved|try placing order again/i);
  await expect(placeOrder).toBeVisible();
  await confirmStockRetrieval(page, placeOrder, stockMessage);
  await page.waitForLoadState('domcontentloaded');
  await waitForQuoteLine(page, '425650-000');

  // 9. Use the page-level Place Order again to open the Order Header frame.
  // A random seven-digit suffix reduces the chance of reusing a PO number.
  const order = await openOrderHeader(page, placeOrder);
  const poNumber = `POSKLNKEVUS${randomInt(10_000_000).toString().padStart(7, '0')}`;
  await order.locator('#orderHeaderCtl_txtMfgPONumber').fill(poNumber);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const calendar = order.locator('#ui-datepicker-div');
  const requestedShip = order.locator('#orderHeaderCtl_dpShipPrefShipDate');
  const poDate = order.locator('#orderHeaderCtl_dpPodate');
  const poRequestedShip = order.locator('#orderHeaderCtl_dpPoRequestedShipDate');

  // Requested ship date requires calendar selection: start one week out on a weekday,
  // move forward if unavailable, and reuse the selected date for PO requested ship date.
  const shipDate = await selectRequestedShipDate(requestedShip, calendar, getNextWeekdayOneWeekOut());
  await selectCalendarDate(calendarTrigger(poDate), calendar, today);
  await selectCalendarDate(calendarTrigger(poRequestedShip), calendar, shipDate);
  await expect(requestedShip).toHaveValue(dateValue(shipDate));
  await expect(poDate).toHaveValue(dateValue(today));
  await expect(poRequestedShip).toHaveValue(dateValue(shipDate));

  // Submit with the Place Order link inside the frame, not the page-level link.
  await order.getByRole('link', { name: 'Place Order', exact: true }).click();

  // 10. Enter the normalized Pricing total as P.O. Amount.
  // Tab triggers ADEPT validation and reveals the approval questions.
  const amount = order.getByRole('spinbutton', { name: 'P.O. Amount (per attached PO)' });
  await amount.fill(poAmount);
  await amount.press('Tab');

  // 11. Answer No for Letter of Credit and Yes for Customer Approval, then Finish.
  await order.getByRole('button', { name: 'Letter of Credit Needed?' }).click();
  await order.getByRole('menuitem', { name: 'No', exact: true }).click();
  await order.getByRole('button', { name: 'Do you have Customer Approval for Procurement?' }).click();
  await order.getByRole('menuitem', { name: 'Yes', exact: true }).click();
  await order.getByText('Finish', { exact: true }).click();

  // 12. Acknowledge the "submitted for review" confirmation.
  const submitted = page.locator('.ui-dialog:visible').filter({ hasText: /submitted for review/i });
  await submitted.getByRole('button', { name: 'OK', exact: true }).click();

  // 13. Open Account Information and log off.
  await page.getByRole('link', { name: 'Account Information' }).click();
  await page.getByRole('link', { name: 'Log Off' }).click();
});
