import { errors, expect, type FrameLocator, type Locator, type Page } from '@playwright/test';
import { orderPageStatus, waitForOrderHeader } from './orderModal';

const stockConfirmation = /check stock has been retrieved|try placing order again/i;

async function confirmStockModal(page: Page, stockMessage: Locator): Promise<void> {
  const dialog = stockMessage.locator(
    'xpath=ancestor-or-self::*[contains(concat(" ", normalize-space(@class), " "), " ui-dialog ") or ' +
    '@role="dialog" or @aria-modal="true" or ' +
    'contains(concat(" ", normalize-space(@class), " "), " modal ")][1]',
  );
  await Promise.all([
    page.waitForEvent('framenavigated', {
      predicate: frame => frame === page.mainFrame(),
      timeout: 60_000,
    }),
    dialog.getByRole('button', { name: 'OK', exact: true }).click(),
  ]);
}

export async function waitForQuoteLine(page: Page, itemNumber: string, timeout = 30_000): Promise<void> {
  const itemCells = page.locator('td.family-name');
  try {
    await expect(itemCells.filter({ hasText: itemNumber })).toBeVisible({ timeout });
  } catch (error) {
    let rows: string;
    try {
      const quoteTable = page.getByRole('table').filter({
        has: page.getByRole('columnheader', { name: 'Item', exact: true }),
      });
      const visibleRows = await quoteTable.locator('tr:visible').allInnerTexts();
      const visibleItems = await itemCells.filter({ visible: true }).allInnerTexts();
      rows = `Visible items: ${visibleItems.map(text => text.trim()).join(' | ') || 'none'}; ` +
        `quote rows: ${visibleRows.map(text => text.replace(/\s+/g, ' ').trim()).filter(Boolean).slice(0, 10).join(' | ') || 'none'}`;
    } catch (diagnosticError) {
      rows = `Quote row diagnostics unavailable: ${String(diagnosticError)}`;
    }
    throw new Error(`Quote line ${itemNumber} was not visible after stock retrieval. ${rows}\n${String(error)}`);
  }
}

export async function confirmStockRetrieval(
  page: Page,
  placeOrder: Locator,
  stockMessage: Locator,
): Promise<void> {
  const pending = new AbortController();
  const messageWait = stockMessage.waitFor({
    state: 'visible',
    timeout: 45_000,
    signal: pending.signal,
  }).then(() => 'modal' as const);
  const browserDialog = page.waitForEvent('dialog', {
    timeout: 0,
    signal: pending.signal,
  }).then(async dialog => {
    if (!stockConfirmation.test(dialog.message())) {
      await dialog.dismiss();
      throw new Error(`Unexpected browser dialog during stock retrieval: ${dialog.message()}`);
    }
    await Promise.all([
      page.waitForEvent('framenavigated', {
        predicate: frame => frame === page.mainFrame(),
        timeout: 60_000,
        signal: pending.signal,
      }),
      dialog.accept(),
    ]);
    return 'browser' as const;
  });

  try {
    const [confirmation] = await Promise.all([
      Promise.race([messageWait, browserDialog]),
      placeOrder.click(),
    ]);
    pending.abort();

    if (confirmation === 'modal') {
      await confirmStockModal(page, stockMessage);
    }
  } finally {
    pending.abort();
  }
}

export async function openOrderHeader(page: Page, placeOrder: Locator, timeout = 30_000): Promise<FrameLocator> {
  const stockMessage = page.getByText(stockConfirmation).filter({ visible: true }).first();
  const order = page.frameLocator('iframe.ui-corner-bottom[frameborder="0"]:visible');
  for (let attempt = 1; attempt <= 2; attempt++) {
    const pending = new AbortController();
    const header = order.locator('#orderHeaderCtl_txtMfgPONumber')
      .waitFor({ state: 'visible', timeout, signal: pending.signal }).then(() => ({ kind: 'header' as const }));
    const modal = stockMessage.waitFor({ state: 'visible', timeout, signal: pending.signal })
      .then(() => ({ kind: 'modal' as const }));
    const browser = page.waitForEvent('dialog', { timeout: 0, signal: pending.signal }).then(async dialog => {
      if (!stockConfirmation.test(dialog.message()) || attempt === 2) {
        const message = dialog.message();
        await dialog.dismiss();
        throw new Error(`Unexpected browser dialog while opening Order Header: ${message}`);
      }
      const refresh = page.waitForEvent('framenavigated', {
        predicate: frame => frame === page.mainFrame(),
        timeout: 60_000,
      }).then(() => null, error => error as unknown);
      await dialog.accept();
      return { kind: 'browser' as const, refresh };
    });

    let result: Awaited<typeof header | typeof modal | typeof browser>;
    try {
      [, result] = await Promise.all([
        placeOrder.click(),
        Promise.race([header, modal, browser]),
      ]);
    } catch (error) {
      if (!(error instanceof errors.TimeoutError)) throw error;
      throw new Error(`Order Header or stock confirmation did not appear. ${await orderPageStatus(page)}\n${String(error)}`);
    } finally {
      pending.abort();
    }

    if (result.kind === 'header') return waitForOrderHeader(page, timeout);
    if (attempt === 2) throw new Error(`Stock confirmation appeared again after retrying Place Order. ${await orderPageStatus(page)}`);
    if (result.kind === 'modal') await confirmStockModal(page, stockMessage);
    if (result.kind === 'browser') {
      const refreshError = await result.refresh;
      if (refreshError !== null) throw refreshError;
    }
    await page.waitForLoadState('domcontentloaded');
  }
  throw new Error('Order Header did not open after retrying Place Order.');
}
