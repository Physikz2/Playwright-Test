import { errors, type Page } from '@playwright/test';

export async function dismissReleaseNotesIfPresent(page: Page): Promise<void> {
  const dismiss = page.getByRole('button', { name: 'Dismiss', exact: true })
    .or(page.getByRole('link', { name: 'Dismiss', exact: true }))
    .or(page.getByText('Dismiss', { exact: true }))
    .filter({ visible: true }).first();

  try {
    await dismiss.waitFor({ state: 'visible', timeout: 5_000 });
  } catch (error) {
    if (error instanceof errors.TimeoutError) return;
    throw error;
  }

  await dismiss.click({ timeout: 5_000 });
  await dismiss.waitFor({ state: 'hidden', timeout: 5_000 });
}

export async function dismissExpediteAlertIfPresent(page: Page): Promise<void> {
  const close = page.getByRole('button', { name: 'close', exact: true })
    .filter({ visible: true }).first();
  try {
    await close.waitFor({ state: 'visible', timeout: 2_000 });
  } catch (error) {
    if (error instanceof errors.TimeoutError) return;
    throw error;
  }
  await close.click({ timeout: 5_000 });
  await close.waitFor({ state: 'hidden', timeout: 5_000 });
}
