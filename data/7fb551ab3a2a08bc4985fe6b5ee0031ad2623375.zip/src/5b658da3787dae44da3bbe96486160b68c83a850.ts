import { errors, test, expect, type Page } from '@playwright/test';
import { getAdeptEnvironment } from '../config/adept';
// 📦 Playwright's core test framework (gives us `test`, `expect`, and running capabilities)

import type * as SimpleStatistics from 'simple-statistics' with { 'resolution-mode': 'import' };
const ss: typeof SimpleStatistics = require('simple-statistics');
// 📊 A lightweight statistics library. We use it for sum() and standardDeviation().

// ============================================================
// INTERFACES: Blueprints for the data we work with
// ============================================================

interface LoadProfileDataPoint {
    // 📊 Represents a single row of load profile data from the API
    loadPercent: number;           // e.g., 0, 5, 10, ... 100
    loadTimeSpentPercent: number;  // e.g., 0.00, 0.80, 1.00, ...
    cost: number;                  // e.g., 0.19
}

interface ApiResponse {
    // 📦 The top-level structure returned by the API
    loadProfile: LoadProfileDataPoint[];
}

// ADEPT can close or rebuild the category menu while the selection page is loading.
async function selectCommercialPumps(page: Page): Promise<void> {
    const category = page.getByLabel('Select box activate');
    const commercialPumps = page.getByRole('link', { name: 'Commercial Pumps', exact: true });

    for (let attempt = 1; attempt <= 4; attempt++) {
        try {
            if (await category.isVisible()) {
                await category.click({ timeout: 5_000 });
            }
            await commercialPumps.click({ timeout: 5_000 });
            return;
        } catch (error) {
            if (!(error instanceof errors.TimeoutError) || attempt === 4) throw error;
            console.log(`Category selection not ready; retrying (${attempt}/4).`);
        }
    }
}

// ============================================================
// TEST: The main executable block
// ============================================================

test('Validate Load Profile & SVG Data', async ({ page }) => {
    // `test` = Playwright's test function
    // `async` = Allows us to use `await` (wait for things to finish) inside this function
    // `({ page })` = Playwright automatically gives us a `page` object that controls the browser

    // ------------------------------------------------------------
    // STEP 1: CALL THE API FOR GROUND TRUTH DATA
    // ------------------------------------------------------------
    // The API endpoint below returns the load profile data for a specific
    // building type, market, system, and zone. This is the "source of truth"
    // that we'll compare the rendered SVG chart against.
    // ------------------------------------------------------------
    // Keep the API and chart on the same configured environment.
    const { environment, baseUrl } = getAdeptEnvironment();
    console.log(`ADEPT environment: ${environment}`);
    const apiUrl = `${baseUrl}/api/LoadProfile/?buildingType=1&marketCode=CA&system=0&zoneNumber=1A`;

    console.log("=== CALLING API FOR GROUND TRUTH ===");
    const apiResponse = await fetch(apiUrl, {
        headers: { "Accept": "application/json, text/plain, */*" }
    });
    // `fetch()` is Node's built-in HTTP client. We pass an Accept header to
    // tell the server we expect JSON.
    const json = await apiResponse.json() as ApiResponse;
    // Parse the response body as JSON and cast it to our ApiResponse interface.
    const apiData = json.loadProfile || [];
    // Extract the loadProfile array. If it's missing, default to empty array.

    // Extract just the loadTimeSpentPercent values into a numeric array
    // so we can run statistical analysis on them.
    const apiTimeSpent = apiData.map(x => x.loadTimeSpentPercent);

    // Calculate the sum of all time-spent values. For a valid load profile,
    // this should equal 100% (the total time spent across all load levels).
    const sumTime = ss.sum(apiTimeSpent);

    // Calculate the standard deviation. This tells us how spread out the
    // data is. A bell curve distribution should have a standard deviation
    // greater than 1. If it's close to 0, the data is flat and likely broken.
    // Note: simple-statistics uses SAMPLE std dev (÷ N-1), which is why it
    // reports 5.10 while numpy (population, ÷ N) reports 5.23.
    const stdDev = apiTimeSpent.length > 1 ? ss.standardDeviation(apiTimeSpent) : 0;

    console.log(`API Total Sum: ${sumTime.toFixed(2)}%`);
    console.log(`API Standard Deviation: ${stdDev.toFixed(2)}`);

    // ------------------------------------------------------------
    // STEP 2: PRINT API DATA TABLE TO CONSOLE
    // ------------------------------------------------------------
    // Display the API data in a readable table format so we can visually
    // inspect the values before comparing them to the SVG data.
    // ------------------------------------------------------------
    console.log("\n--- API LOAD PROFILE DATA (GROUND TRUTH) ---");
    console.log("Load %     | Time Spent %    | Cost      ");
    console.log("-".repeat(40));
    for (const pt of apiData) {
        console.log(`${pt.loadPercent.toFixed(1).padEnd(10)} | ${pt.loadTimeSpentPercent.toFixed(2).padEnd(15)} | ${pt.cost.toFixed(2).padEnd(10)}`);
    }

    // ------------------------------------------------------------
    // STEP 3: OPEN THE BROWSER AND NAVIGATE
    // ------------------------------------------------------------
    console.log("\n[STEP] Navigating to application URL...");
    await page.goto(baseUrl);
    // `page.goto()` tells the browser to go to this URL. The `await` waits
    // until the page starts loading.

    // Dismiss month-specific Release Notes whenever they interrupt a later action.
    const releaseTitle = page.getByText(
        /^\s*(?:January|February|March|April|May|June|July|August|September|October|November|December)(?:\s+\d{4})?\s+Release(?:\s+Notes)?\s*$/i,
    ).filter({ visible: true });
    // Scope Dismiss to the closest container shared with the release title.
    const releasePage = releaseTitle.first().locator('xpath=ancestor::*[.//*[normalize-space(.)="Dismiss"]][1]');
    const releaseDismiss = releasePage.getByRole('button', { name: 'Dismiss', exact: true })
        .or(releasePage.getByRole('link', { name: 'Dismiss', exact: true }))
        .or(releasePage.getByText('Dismiss', { exact: true }))
        .filter({ visible: true }).first();
    await page.addLocatorHandler(releaseDismiss, async button => {
        try {
            await button.click({ timeout: 5_000 });
        } catch (error) {
            if (!(error instanceof errors.TimeoutError) || page.isClosed() || await button.isVisible()) throw error;
            console.log('Release Notes disappeared before dismissal.');
        }
    });

    // ------------------------------------------------------------
    // STEP 4: CLICK "PUBLIC USER" BUTTON
    // ------------------------------------------------------------
    // The app displays a "Public User" prompt on first load. Clicking it
    // dismisses the modal gracefully (better than nuking it from the DOM).
    // We use try/catch because the button may not always appear.
    // ------------------------------------------------------------
    console.log("[STEP] Clicking 'Public User' button...");
    const publicUserButton = page.getByRole('button', { name: 'Public User', exact: true });
    const publicUserOverlay = publicUserButton.locator('..').locator('.wm-visual-design-shape');
    try {
        await publicUserButton.waitFor({ state: 'visible', timeout: 10_000 });
        if (await publicUserOverlay.isVisible()) {
            await publicUserOverlay.click({ timeout: 10_000 });
        } else {
            await publicUserButton.click({ timeout: 10_000 });
        }
        console.log("Successfully clicked 'Public User'.");
    } catch (error) {
        if (!(error instanceof errors.TimeoutError) || page.isClosed() ||
            await publicUserButton.isVisible() || await releaseDismiss.isVisible()) throw error;
        console.log("[INFO] 'Public User' button didn't appear. Skipping.");
    }

    // ------------------------------------------------------------
    // STEP 6: NAVIGATE TO "COMMERCIAL PUMPS"
    // ------------------------------------------------------------
    // Open the category dropdown and select "Commercial Pumps".
    // ------------------------------------------------------------
    console.log("[STEP] Waiting for dropdown toggle and caret...");
    await selectCommercialPumps(page);

    // ------------------------------------------------------------
    // STEP 7: CLICK "GO" BUTTON
    // ------------------------------------------------------------
    console.log("[STEP] Waiting for 'Go' button...");
    await page.locator("//div[contains(@class, 'button-text') and normalize-space()='Go']").click();

    // ------------------------------------------------------------
    // STEP 8: CLICK "SELECT ALL" AND SELECT FIRST PUMP
    // ------------------------------------------------------------
    // Select All toggles all pump options. Then we drill down to the
    // first pump and select its nested configuration.
    // ------------------------------------------------------------
    console.log("[STEP] Waiting for 'Select All' checkbox...");
    await page.locator("//saa-check-box[@control-title='Select All']//label[@class='text'] | //label[normalize-space()='Select All']").click();

    console.log("[STEP] Waiting for first pump option...");
    await page.locator(".screenOptions:nth-child(2) .box-delegate").click();

    console.log("[STEP] Waiting for nested option...");
    await page.locator(".ng-scope:nth-child(1) > .single-line:nth-child(1) .view-elements:nth-child(2) .screenOptions:nth-child(3) > .ng-scope:nth-child(1) .box-delegate:nth-child(2)").click();

    // ------------------------------------------------------------
    // STEP 9: OPEN THE "LOAD PROFILE" TAB
    // ------------------------------------------------------------
    console.log("[STEP] Waiting for Load Profile tab...");
    await page.locator(".uib-tab:nth-child(4) > .nav-link > .ng-binding").click();

    // ------------------------------------------------------------
    // STEP 10: EXTRACT SVG DATA FROM THE CHART
    // ------------------------------------------------------------
    // The load profile chart is rendered as an SVG. We extract:
    //   1. The `viewBox` attribute (defines the coordinate system)
    //   2. The `d` attribute of the path element (contains the curve)
    // ------------------------------------------------------------
    console.log("[STEP] Waiting for chart SVG container...");
    const svgEl = page.locator("svg").first();
    const viewBox = await svgEl.getAttribute("viewBox") || "";

    const svgPath = page.locator("path.area[fill='#F20']").first();
    const dAttribute = await svgPath.getAttribute("d") || "";
    console.log("[STEP] Successfully extracted SVG path data.");

    // ------------------------------------------------------------
    // STEP 11: STAGE 1 - RAW CURVE POINTS
    // ------------------------------------------------------------
    // Extract the raw X,Y coordinates from the SVG path `d` attribute.
    // Note: The SVG path contains TWO halves (a forward curve and a
    // backward curve to close the shape). We only want the first half.
    // ------------------------------------------------------------
    const rawPoints = extractRawPoints(dAttribute);
    const halfCount = Math.floor(rawPoints.length / 2);

    console.log("\n--- STAGE 1: RAW CURVE (X, Y) COORDINATES (FIRST 21 POINTS) ---");
    console.log("Index  | Raw X      | Raw Y     ");
    console.log("-".repeat(34));
    for (let i = 0; i < halfCount; i++) {
        console.log(`${i.toString().padEnd(6)} | ${rawPoints[i].x.toFixed(1).padEnd(10)} | ${rawPoints[i].y.toFixed(1).padEnd(10)}`);
    }

    // ------------------------------------------------------------
    // STEP 12: STAGE 2 - UNNORMALIZED NUMBER MAPPING
    // ------------------------------------------------------------
    // Decode the raw SVG coordinates into meaningful (Flow, Time) values.
    // At this stage, the Time values are NOT yet normalized.
    //
    // Formula:
    //   Flow = (RawX / svgWidth) * 100
    //   Time = (svgHeight - RawY) / svgHeight
    //
    // We subtract RawY from svgHeight because SVG Y coordinates increase
    // downward, but we want Time to increase upward.
    // ------------------------------------------------------------
    const unnormalizedData = decodeSVGUnnormalized(dAttribute, viewBox);
    console.log("\n--- STAGE 2: RAW NUMBER MAPPING (UNNORMALIZED) ---");
    console.log("Flow %     | Raw Time Value ");
    console.log("-".repeat(30));
    for (const pt of unnormalizedData) {
        console.log(`${pt.flow.toFixed(1).padEnd(10)} | ${pt.time.toFixed(4).padEnd(15)}`);
    }

    // ------------------------------------------------------------
    // STEP 13: STAGE 3 - FINAL ADJUSTED (NORMALIZED TO 100%)
    // ------------------------------------------------------------
    // The unnormalized Time values don't sum to 100%, so we normalize
    // them. This scales all values proportionally so that the total
    // equals 100%, matching the API's format.
    // ------------------------------------------------------------
    const finalData = decodeSVGToPercentages(dAttribute, viewBox);
    console.log("\n--- STAGE 3: FINAL ADJUSTED (NORMALIZED TO 100%) TABLE ---");
    console.log("Flow %     | Normalized Time % ");
    console.log("-".repeat(33));
    for (const pt of finalData) {
        console.log(`${pt.flow.toFixed(1).padEnd(10)} | ${pt.time.toFixed(2).padEnd(18)}`);
    }

    // ------------------------------------------------------------
    // STEP 14: SIDE-BY-SIDE COMPARISON
    // ------------------------------------------------------------
    // Compare the API data (ground truth) with the decoded SVG data
    // (what's actually rendered on the chart). If they match, the
    // chart is rendering correctly.
    // ------------------------------------------------------------
    console.log("\n=== SIDE-BY-SIDE FINAL BASE COMPARE ===");
    console.log("API Flow   | API Time   || Final Flow | Final Time");
    console.log("-".repeat(48));
    const maxCount = Math.max(apiData.length, finalData.length);
    for (let i = 0; i < maxCount; i++) {
        const apiF = i < apiData.length ? apiData[i].loadPercent.toFixed(1) : "-";
        const apiT = i < apiData.length ? apiData[i].loadTimeSpentPercent.toFixed(2) : "-";
        const svgF = i < finalData.length ? finalData[i].flow.toFixed(1) : "-";
        const svgT = i < finalData.length ? finalData[i].time.toFixed(2) : "-";
        console.log(`${apiF.padEnd(10)} | ${apiT.padEnd(10)} || ${svgF.padEnd(10)} | ${svgT.padEnd(10)}`);
    }

    console.log("\nFINAL: ALL DIAGNOSTIC STAGES PRINTED SUCCESSFULLY");

    // ------------------------------------------------------------
    // STEP 15: ASSERTIONS (THE PASS/FAIL CHECK)
    // ------------------------------------------------------------
    // These are the real tests. If any assertion fails, the test fails.
    // ------------------------------------------------------------

    // Verify the API data sums to ~100% (the load profile total)
    console.log(`\n[ASSERTION] Checking Total Sum... Expected >95 and <105. Got: ${sumTime.toFixed(2)}`);
    expect(sumTime).toBeGreaterThan(95);
    expect(sumTime).toBeLessThan(105);

    // Verify the data has meaningful variation (bell curve, not flat)
    console.log(`[ASSERTION] Checking Standard Deviation... Expected >1.0. Got: ${stdDev.toFixed(2)}`);
    expect(stdDev).toBeGreaterThan(1.0);

    // Verify we actually decoded some data points from the SVG
    console.log(`[ASSERTION] Checking Data Points... Expected >0. Got: ${finalData.length}`);
    expect(finalData.length).toBeGreaterThan(0);

    console.log("\n[RESULT] ALL ASSERTIONS PASSED!");

    // ------------------------------------------------------------
    // STEP 16: PAUSE THE TEST (Keeps browser open for inspection)
    // ------------------------------------------------------------
    // Opens the Playwright Inspector so you can:
    //   - Hover over elements to find locators
    //   - Step through the code
    //   - Inspect the DOM
    // Click "Resume" in the Inspector to finish the test.
    // ------------------------------------------------------------
    //await page.pause();
});

// ============================================================
// HELPER FUNCTIONS (Exact copy from the proven C# logic)
// ============================================================

// -------------------------------------------------------------------------
// HELPER: extractRawPoints
// -------------------------------------------------------------------------
// Parses the SVG path `d` attribute and extracts all X,Y coordinate pairs
// using a regular expression.
//
// The `d` attribute contains commands like:
//   M 0,350 L 19,340.7 L 38,338.3 ...
//
// The regex looks for patterns like "19,340.7" and extracts the numbers.
// -------------------------------------------------------------------------
function extractRawPoints(dAttribute: string): { x: number, y: number }[] {
    const points: { x: number, y: number }[] = [];
    const regex = /([\d\.\-]+),([\d\.\-]+)/g;
    let match;
    
    while ((match = regex.exec(dAttribute)) !== null) {
        points.push({ x: parseFloat(match[1]), y: parseFloat(match[2]) });
    }
    return points;
}

// -------------------------------------------------------------------------
// HELPER: decodeSVGUnnormalized
// -------------------------------------------------------------------------
// Converts raw SVG coordinates into (Flow, Time) values WITHOUT normalizing
// them. The Time values won't sum to 100%.
//
// Formula:
//   Flow = (RawX / svgWidth) * 100
//   Time = (svgHeight - RawY) / svgHeight
// -------------------------------------------------------------------------
function decodeSVGUnnormalized(dAttribute: string, _viewBox: string): { flow: number, time: number }[] {
    const svgWidth = 380;
    const svgHeight = 350;

    const rawPoints = extractRawPoints(dAttribute);
    if (rawPoints.length === 0) return [];

    // Only use the first half of the points (the forward curve)
    const halfCount = Math.floor(rawPoints.length / 2);
    const results: { flow: number, time: number }[] = [];
    for (let i = 0; i < halfCount; i++) {
        const flow = (rawPoints[i].x / svgWidth) * 100.0;
        const time = (svgHeight - rawPoints[i].y) / svgHeight;
        results.push({ flow: Math.round(flow * 10) / 10, time });
    }
    return results;
}

// -------------------------------------------------------------------------
// HELPER: decodeSVGToPercentages
// -------------------------------------------------------------------------
// Converts raw SVG coordinates into (Flow, Time) values AND normalizes the
// Time values so they sum to 100%. This matches the API's format.
// -------------------------------------------------------------------------
function decodeSVGToPercentages(dAttribute: string, _viewBox: string): { flow: number, time: number }[] {
    const svgWidth = 380;
    const svgHeight = 350;

    const rawPoints = extractRawPoints(dAttribute);
    if (rawPoints.length === 0) return [];

    const halfCount = Math.floor(rawPoints.length / 2);
    const flows: number[] = [];
    const times: number[] = [];

    for (let i = 0; i < halfCount; i++) {
        const flow = (rawPoints[i].x / svgWidth) * 100.0;
        // Here we DON'T divide by svgHeight. We just invert Y.
        // This gives us a raw "time" value that we'll normalize later.
        const timeVal = svgHeight - rawPoints[i].y;
        flows.push(flow);
        times.push(timeVal);
    }

    // Calculate the sum of all raw time values
    const totalTimeSum = ss.sum(times);
    const normalizedResults: { flow: number, time: number }[] = [];

    // Normalize each time value so the total equals 100%
    for (let i = 0; i < halfCount; i++) {
        const normTime = totalTimeSum > 0 ? (times[i] / totalTimeSum) * 100.0 : 0;
        normalizedResults.push({
            flow: Math.round(flows[i] * 10) / 10,
            time: Math.round(normTime * 100) / 100
        });
    }

    return normalizedResults;
}