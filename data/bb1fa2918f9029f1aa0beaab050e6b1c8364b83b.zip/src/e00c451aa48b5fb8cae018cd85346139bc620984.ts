import { errors, test, expect, type Page } from '@playwright/test'; 
import { getAdeptEnvironment } from '../config/adept';
// 📦 Playwright's core test framework (gives us `test`, `expect`, and running capabilities)

import * as fs from 'fs';
// 🗂️ Node.js built-in File System module. We use this to write JSON files.

// ============================================================
// INTERFACES: These are like "blueprints" for the data we will work with.
// ============================================================

interface CurveData {
    // 📊 Represents the data returned from the "Get Curve" API
    title: string;          // The main title (e.g., "Series 4322")
    subTitle: string;       // The sub-title (e.g., "3x3x5 @ 3762 rpm")
    curveSeries: any[];     // The array of X/Y coordinates that make up the curve
}

// ADEPT can close or rebuild the category menu while the selection page is loading.
async function selectCommercialPumps(page: Page): Promise<void> {
    const category = page.getByLabel('Select box activate');
    const commercialPumps = page.getByRole('link', { name: 'Commercial Pumps', exact: true });

    for (let attempt = 1; attempt <= 4; attempt++) {
        try {
            if (await category.isVisible()) {
                await category.click({ timeout: 5_000 });
            }
            await commercialPumps.click({ timeout: 5_000 });
            return;
        } catch (error) {
            if (!(error instanceof errors.TimeoutError) || attempt === 4) throw error;
            console.log(`Category selection not ready; retrying (${attempt}/4).`);
        }
    }
}

// ============================================================
// TEST: The main executable block
// ============================================================

test('Validate Pump Curve Data & Image Generation', async ({ page }, testInfo) => {
    // `test` = Playwright's test function
    // `async` = Allows us to use `await` (wait for things to finish) inside this function
    // `({ page })` = Playwright automatically gives us a `page` object that controls the browser

    // ------------------------------------------------------------
    // STEP 1: Navigate to the app
    // ------------------------------------------------------------
    console.log("\n[STEP] Navigating to application URL...");
    const { environment, baseUrl } = getAdeptEnvironment();
    console.log(`ADEPT environment: ${environment}`);
    await page.goto(baseUrl);
    // `page.goto()` tells the browser to go to this URL. The `await` waits until the page starts loading.

    // Dismiss month-specific Release Notes whenever they interrupt a later action.
    const releaseTitle = page.getByText(
        /^\s*(?:January|February|March|April|May|June|July|August|September|October|November|December)(?:\s+\d{4})?\s+Release(?:\s+Notes)?\s*$/i,
    ).filter({ visible: true });
    // Scope Dismiss to the closest container shared with the release title.
    const releasePage = releaseTitle.first().locator('xpath=ancestor::*[.//*[normalize-space(.)="Dismiss"]][1]');
    const releaseDismiss = releasePage.getByRole('button', { name: 'Dismiss', exact: true })
        .or(releasePage.getByRole('link', { name: 'Dismiss', exact: true }))
        .or(releasePage.getByText('Dismiss', { exact: true }))
        .filter({ visible: true }).first();
    await page.addLocatorHandler(releaseDismiss, async button => {
        try {
            await button.click({ timeout: 5_000 });
        } catch (error) {
            if (!(error instanceof errors.TimeoutError) || page.isClosed() || await button.isVisible()) throw error;
            console.log('Release Notes disappeared before dismissal.');
        }
    });

    //await page.waitForTimeout(3000);
    //await page.pause();

    // ------------------------------------------------------------
    // STEP 2: Handle "Public User" modal (The popup that blocks the screen)
    // ------------------------------------------------------------
    console.log("[STEP] Clicking 'Public User' button...");
    try {
        // first wait for the button 
        await page.getByText('Public User', { exact: true }).first().waitFor({ state: 'visible', timeout: 10000 });
        // The button IS there, just use force: true to click it immediately
        await page.getByText('Public User', { exact: true }).first().click({ timeout: 10000, force: true });
        console.log("[INFO] 'Public User' button clicked successfully!");    
    } catch (error) {
        if (!(error instanceof errors.TimeoutError) || page.isClosed() ||
            await page.getByText('Public User', { exact: true }).first().isVisible() ||
            await releaseDismiss.isVisible()) throw error;
        // The Public User prompt is optional.
        console.log("[INFO] 'Public User' button didn't appear. Skipping.");
    }

    // ------------------------------------------------------------
    // STEP 4: Navigate to Commercial Pumps
    // ------------------------------------------------------------
    console.log("[STEP] Selecting Commercial Pumps...");
    await selectCommercialPumps(page);

    // ------------------------------------------------------------
    // STEP 5: Click "Go" button
    // ------------------------------------------------------------
    console.log("[STEP] Clicking 'Go' button...");
    await page.getByText('Go', { exact: true }).click();

    // ------------------------------------------------------------
    // STEP 6: Unselect all pumps (So we can pick just one later)
    // ------------------------------------------------------------
    console.log("[STEP] Unselecting all pumps...");
    await page.getByText('Select All').click();
    await page.waitForTimeout(3000); 
    // ⏳ Wait 3 seconds for Angular to re-render the UI after clicking.

    // ------------------------------------------------------------
    // STEP 7: Select ONLY the 4322 pump
    // ------------------------------------------------------------
    console.log("[STEP] Selecting 4322 ONLY...");
    await page.getByText('4322', { exact: true }).first().click();
    // We click the visible text "4322". `.first()` resolves Playwright's "strict mode violation" 
    // (when there are two elements with the same text) by clicking the first one.

    // ------------------------------------------------------------
    // STEP 8: Fill in Flow and Head
    // ------------------------------------------------------------
    console.log("[STEP] Filling in Flow=500, Head=100...");
    await page.getByLabel('Total System Flow').fill("500"); // Find input by label text and type 500
    await page.getByLabel('System Head').fill("100");        // Find input by label text and type 100
    await page.keyboard.press("Tab");                        // Tab out so the UI updates (activates "Get Results")
    await page.waitForTimeout(1000);                         // Wait for UI to settle

    // ------------------------------------------------------------
    // STEP 9: Prepare per-test output paths to avoid collisions between concurrent runs
    // ------------------------------------------------------------
    const getResultsPath = testInfo.outputPath('single-curve-get-results.json');
    const showCurvesPath = testInfo.outputPath('single-curve-show-curves.json');

    // ------------------------------------------------------------
    // STEP 10: Click "Get Results" and CAPTURE the API response
    // ------------------------------------------------------------
    console.log("[STEP] Clicking 'Get Results' button...");
    // CRITICAL: We must SET UP the waitForResponse BEFORE clicking the button.
    const getResultsPromise = page.waitForResponse('**/ButtonClick');
    console.log("[API] Waiting for endpoint: **/ButtonClick");
    // This sets up a "listener" for any API call matching "**/ButtonClick" (the Get Results API).
    
    await page.getByText('Get Results', { exact: true }).click();
    // Now we click "Get Results". The API call fires immediately.
    
    const getResultsResponse = await getResultsPromise;
    // `await` blocks until the API call completes, then grabs the response.
    console.log(`[API] ✅ Received response from: ${getResultsResponse.url()}`);
    // This logs the FULL URL of the API endpoint
    
    const getResultsJson = await getResultsResponse.json();
    // Convert the raw response into a JavaScript object (JSON).

    // ------------------------------------------------------------
    // STEP 11: Save the Grid data to a file
    // ------------------------------------------------------------
    fs.writeFileSync(getResultsPath, JSON.stringify(getResultsJson, null, 2));
    console.log(`📁 SAVED: ${getResultsPath}`);

    await page.waitForTimeout(3000);
    // ⏳ Wait 3 seconds for the grid to fully render.

    // ------------------------------------------------------------
    // STEP 12: Capture the "Get Curve" API (The Show Curves response)
    // ------------------------------------------------------------
    console.log("[STEP] Preparing to intercept 'Get Curve' API...");
    // CRITICAL: Set up the waitForResponse BEFORE clicking "Show Curves" again!
    const getCurveResponsePromise = page.waitForResponse('**/GetCurveResultEx');
    console.log("[API] Waiting for endpoint: **/GetCurveResultEx");
    
    console.log("[STEP] Clicking 'Show Curves' button...");
    await page.getByText('Show Curves', { exact: true }).click();
    // Click the visible text "Show Curves".
    
    const getCurveResponse = await getCurveResponsePromise;
    // Wait for the API call to come back.
    console.log(`[API] ✅ Received response from: ${getCurveResponse.url()}`);
    // This logs the FULL URL of the API endpoint
    
    const getCurveJson = await getCurveResponse.json();
    // Convert response to a JavaScript object.

    // ------------------------------------------------------------
    // STEP 13: Save the Curve data to a file
    // ------------------------------------------------------------
    fs.writeFileSync(showCurvesPath, JSON.stringify(getCurveJson, null, 2));
    console.log(`📁 SAVED: ${showCurvesPath}`);

    let curveData: CurveData = {
        // Create a structure to hold the curve data
        title: getCurveJson.title,
        subTitle: getCurveJson.subTitle,
        curveSeries: getCurveJson.curveSeries
    };

    // ------------------------------------------------------------
    // STEP 14: Wait for the curve image to appear on the grid
    // ------------------------------------------------------------
    console.log("[STEP] Waiting for the curve image (svg) to appear...");
    const curveImage = page.locator("div.grid-overlay, svg").first();
    // Look for the first `div.grid-overlay` OR `svg` (the curve image).
    await curveImage.waitFor({ state: 'visible', timeout: 15000 });
    // Wait up to 15 seconds for the curve image to become visible.

    // ------------------------------------------------------------
    // STEP 15: Assertions (The "Pass/Fail" check)
    // ------------------------------------------------------------
    expect(await curveImage.isVisible()).toBeTruthy();
    // If the image is visible, this passes. If not, the test fails.
    console.log("[RESULT] Curve image generated successfully!");

    // ------------------------------------------------------------
    // STEP 16: Keep browser open ONLY if the test FAILS
    // ------------------------------------------------------------
    if (test.info().status !== 'passed') {
        await page.pause();
        // If the test fails, open Playwright Inspector so we can debug.
    }
});